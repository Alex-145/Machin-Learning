from typing import List

plate_segmentation_model: str = 'process/computer_vision_models/models/plate_segmentation.pt'
plate_segmentation_classes: List[str] = ['vehicle plate']
