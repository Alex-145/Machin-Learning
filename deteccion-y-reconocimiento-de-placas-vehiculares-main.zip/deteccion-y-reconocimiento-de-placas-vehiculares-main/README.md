# reconocimiento-de-placas-vehiculares
Hola, chicos en este repositorio encontrarán la programación para que puedan crear su sistema de reconocimiento de placas vehiculares, utilizando inteligencia artificial.
